package com.cutenessbybec.DiscoverFish;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.cutenessbybec.DiscoverFish.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class MyAdapter1 extends RecyclerView.Adapter<MyAdapter1.MyViewHolder> {
    private ArrayList<Fish> mDataset;
    private static AdapterOnClickHandler mAdapterOnClickHandler;

    public MyAdapter1(ArrayList<Fish> myDataset,AdapterOnClickHandler clickHandler) {
        mDataset = myDataset;
        mAdapterOnClickHandler = clickHandler;
    }

    public interface AdapterOnClickHandler {
        void onClick(int position);
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        public LinearLayout linearLayout;
        public TextView textView;
        public ImageView imageView;
        public Button unfavorite;
        public MyViewHolder(LinearLayout v) {
            super(v);
            linearLayout = v;
            textView = v.findViewById(R.id.faveTextView);
            imageView = v.findViewById(R.id.faveImageView);
            unfavorite = v.findViewById(R.id.unfavorite);
            v.setOnClickListener(this);

        }
        @Override
        public void onClick(View v) {
            int adapterPosition = getAdapterPosition();
            mAdapterOnClickHandler.onClick(adapterPosition);
        }
    }

    // Create new views (invoked by the layout manager)
    @Override
    public MyAdapter1.MyViewHolder onCreateViewHolder(ViewGroup parent,
                                                      int viewType) {
        // Creates the new view for each cell. Instead of a simple TextView,
        // this can be a CardView or a ViewGroup
        LinearLayout v = (LinearLayout) LayoutInflater.from(parent.getContext())
                .inflate(R.layout.favorite_view, parent, false);

        MyAdapter1.MyViewHolder vh = new MyAdapter1.MyViewHolder(v);

        return vh;
    }

    // Replace the contents of a view (invoked by the layout manager)
    @Override
    public void onBindViewHolder(MyAdapter1.MyViewHolder holder, final int position) {
        if(position%2==0) {
            holder.linearLayout.setBackgroundColor(-1);
        } else {
            holder.linearLayout.setBackgroundColor(0);
        }
        Picasso.get().load(mDataset.get(position).image).into(holder.imageView);
        if(mDataset.get(position).FBname==null) {
            holder.textView.setText(mDataset.get(position).Genus + " " + mDataset.get(position).Species);

        } else {
            holder.textView.setText(mDataset.get(position).FBname + "\n" + mDataset.get(position).Genus + " " + mDataset.get(position).Species);
        }
        holder.unfavorite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity.faveList.remove(MainActivity.faveList.get(position));
                FragmentMain.mAdapter.notifyDataSetChanged();
                notifyDataSetChanged();
            }
        });
    }

    @Override
    public int getItemViewType(int position){
        return position;
    }

    // Return the size of our dataset (invoked by the layout manager)
    @Override
    public int getItemCount() {
        return mDataset.size();
    }
}
