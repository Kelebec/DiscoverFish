package com.cutenessbybec.DiscoverFish;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.cutenessbybec.DiscoverFish.R;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentFavorites extends Fragment implements MyAdapter1.AdapterOnClickHandler{

    private static RecyclerView recyclerView;
    private static RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;

    public FragmentFavorites() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_favorites, container, false);

        recyclerView = rootView.findViewById(R.id.favorites);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);
        mAdapter = new MyAdapter1(MainActivity.faveList, FragmentFavorites.this);
        recyclerView.setAdapter(mAdapter);

        return rootView;
    }

    @Override
    public void onClick(int position) {
        Intent i =  new Intent(getActivity(), DetailsActivity.class);
        boolean fromFaves = true;
        i.putExtra("index",position);
        i.putExtra("fromFaves",fromFaves);
        startActivity(i);
    }

}
