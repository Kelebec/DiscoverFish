package com.cutenessbybec.DiscoverFish;

import java.util.List;

public class Data {
    public List<Fish> data;

}