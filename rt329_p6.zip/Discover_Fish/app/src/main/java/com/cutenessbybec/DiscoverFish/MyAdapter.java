package com.cutenessbybec.DiscoverFish;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ToggleButton;

import androidx.recyclerview.widget.RecyclerView;

import com.cutenessbybec.DiscoverFish.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {
    private ArrayList<Fish> mDataset;
    private static AdapterOnClickHandler mAdapterOnClickHandler;

    public MyAdapter(ArrayList<Fish> myDataset, AdapterOnClickHandler clickHandler) {
        mDataset = myDataset;
        mAdapterOnClickHandler = clickHandler;
    }

    public interface AdapterOnClickHandler {
        void onClick(int position);
    }

    // Define a custom view holder for each item in the list
    public static class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        // Instantiate all the components that changes in the list
        // Any objects that are initialized here can be modified in
        // onBindViewHolder(...)
        public LinearLayout linearLayout;
        public TextView textView;
        public ImageView imageView;
        public ToggleButton toggleButton;
        public MyViewHolder(LinearLayout v) {
            super(v);
            linearLayout = v;
            textView = v.findViewById(R.id.textView);
            imageView = v.findViewById(R.id.imageView);
            toggleButton = v.findViewById(R.id.toggleButton);
            v.setOnClickListener(this);
        }
        @Override
        public void onClick(View v) {
            int adapterPosition = getAdapterPosition();
            mAdapterOnClickHandler.onClick(adapterPosition);
        }
    }

    @Override
    public MyAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent,
                                                     int viewType) {

        LinearLayout v = (LinearLayout) LayoutInflater.from(parent.getContext())
                .inflate(R.layout.main_view, parent, false);

        MyViewHolder vh = new MyViewHolder(v);

        return vh;
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, final int position) {
        if(position%2==0) {
            holder.linearLayout.setBackgroundColor(-1);
        } else {
            holder.linearLayout.setBackgroundColor(0);
        }
        if(MainActivity.faveList.contains(mDataset.get(position))) {
            holder.toggleButton.setChecked(true);
        } else {
            holder.toggleButton.setChecked(false);
        }
        Picasso.get().load(mDataset.get(position).image).into(holder.imageView);
        if(mDataset.get(position).FBname == null) {
            holder.textView.setText(mDataset.get(position).Genus + " " + mDataset.get(position).Species);
        } else {
            holder.textView.setText(mDataset.get(position).FBname + "\n" + mDataset.get(position).Genus + " " + mDataset.get(position).Species);
        }
        holder.toggleButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b==true){
                    MainActivity.faveList.add(mDataset.get(position));
                } else {
                    MainActivity.faveList.remove(mDataset.get(position));
                }
            }
        });
    }

    @Override
    public int getItemViewType(int position){
        return position;
    }

    @Override
    public int getItemCount() {
        return mDataset.size();
    }
}
