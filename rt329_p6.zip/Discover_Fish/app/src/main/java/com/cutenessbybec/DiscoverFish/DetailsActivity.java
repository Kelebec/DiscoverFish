package com.cutenessbybec.DiscoverFish;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.cutenessbybec.DiscoverFish.R;
import com.squareup.picasso.Picasso;

public class DetailsActivity extends Activity {

    private int index;
    private boolean fromFaves;

    TextView commonName;
    TextView scientificName;
    TextView comments;
    ImageView fishImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        commonName = findViewById(R.id.commonName);
        scientificName = findViewById(R.id.scientificName);
        comments = findViewById(R.id.comments);
        fishImage = findViewById(R.id.fishImage);

        Bundle b = getIntent().getExtras();
        if(b!=null){

            index = b.getInt("index");
            fromFaves = b.getBoolean("fromFaves");

            if(fromFaves==false) {
                Picasso.get().load(MainActivity.fishList.get(index).image).into(fishImage);
                if(MainActivity.fishList.get(index).FBname!=null) {
                    commonName.setText(MainActivity.fishList.get(index).FBname);
                }
                scientificName.setText(MainActivity.fishList.get(index).Genus + " " + MainActivity.fishList.get(index).Species);
                comments.setText(MainActivity.fishList.get(index).Comments);
            } else {
                Picasso.get().load(MainActivity.faveList.get(index).image).into(fishImage);
                commonName.setText(MainActivity.faveList.get(index).FBname);
                scientificName.setText(MainActivity.faveList.get(index).Genus + " " + MainActivity.fishList.get(index).Species);
                comments.setText(MainActivity.faveList.get(index).Comments);
            }

        }
    }
}
