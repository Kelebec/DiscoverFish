package com.cutenessbybec.DiscoverFish;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.cutenessbybec.DiscoverFish.R;
import com.squareup.moshi.JsonAdapter;
import com.squareup.moshi.Moshi;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;


public class FragmentMain extends Fragment implements MyAdapter.AdapterOnClickHandler{

    private RecyclerView recyclerView;
    public static RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;
    private Button discoverFish;

    public FragmentMain() {

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_main, container, false);

        discoverFish = rootView.findViewById(R.id.discoverFish);

        recyclerView = rootView.findViewById(R.id.my_recycler_view);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);

        if (MainActivity.fishList.isEmpty()) {

            int[] offset = {0,0,0,0};

            for(int i = 0;i<4;i++) {
                offset[i] = ThreadLocalRandom.current().nextInt(0, 34342);

                OkHttpClient client = new OkHttpClient();
                String url = "https://fishbase.ropensci.org/species?limit=1&offset="+offset[i];

                Request request = new Request.Builder()
                        .url(url)
                        .build();

                client.newCall(request).enqueue(new Callback() {
                    @Override
                    public void onFailure(@NotNull Call call, @NotNull IOException e) {
                        e.printStackTrace();
                    }

                    @Override
                    public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                        if (!response.isSuccessful()) {
                            throw new IOException("Unexpected code " + response);
                        } else {
                            Moshi moshi = new Moshi.Builder().build();
                            JsonAdapter<Data> jsonAdapter = moshi.adapter(Data.class);

                            Data data = jsonAdapter.fromJson(response.body().string());

                            final ArrayList<Fish> fish = (ArrayList) data.data;
                            MainActivity.fishList.add(fish.get(0));

                            getActivity().runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    mAdapter.notifyDataSetChanged();
                                }
                            });

                        }
                    }
                });
            }
        }

        mAdapter = new MyAdapter(MainActivity.fishList,FragmentMain.this);
        recyclerView.setAdapter(mAdapter);


        discoverFish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int[] offset = {0,0,0,0};

                for(int i = 0; i<4; i++) {
                    offset[i] = ThreadLocalRandom.current().nextInt(0, 34342);
                    final int place = i;

                    OkHttpClient client = new OkHttpClient();
                    String url = "https://fishbase.ropensci.org/species?limit=1&offset="+offset[i];

                    Request request = new Request.Builder()
                            .url(url)
                            .build();

                    client.newCall(request).enqueue(new Callback() {
                        @Override
                        public void onFailure(@NotNull Call call, @NotNull IOException e) {
                            e.printStackTrace();
                        }

                        @Override
                        public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                            if (!response.isSuccessful()) {
                                throw new IOException("Unexpected code " + response);
                            } else {
                                Moshi moshi = new Moshi.Builder().build();
                                JsonAdapter<Data> jsonAdapter = moshi.adapter(Data.class);

                                Data data = jsonAdapter.fromJson(response.body().string());

                                final ArrayList<Fish> fish = (ArrayList) data.data;
                                MainActivity.fishList.set(place,fish.get(0));

                                getActivity().runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        mAdapter.notifyDataSetChanged();
                                    }
                                });
                            }
                        }
                    });
                }
            }
        });

        return rootView;
    }

    @Override
    public void onClick(int position) {
        Intent i =  new Intent(getActivity(), DetailsActivity.class);
        boolean fromFaves = false;
        i.putExtra("index",position);
        i.putExtra("fromFaves",fromFaves);
        startActivity(i);
    }

}
