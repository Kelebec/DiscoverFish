package com.cutenessbybec.DiscoverFish;

public class Fish {
    String Genus;
    String Species;
    String FBname;
    String Comments;
    String image;
    int Fresh;
    int Brack;
    int Saltwater;
}
